CREATE VIEW SCHEMATA_EXTENSIONS AS
SELECT `cat`.`name`                           AS `CATALOG_NAME`,
       `sch`.`name`                           AS `SCHEMA_NAME`,
       get_dd_schema_options(`sch`.`options`) AS `OPTIONS`
FROM (`mysql`.`schemata` `sch` JOIN `mysql`.`catalogs` `cat` ON ((`cat`.`id` = `sch`.`catalog_id`)))
WHERE (0 <> can_access_database(`sch`.`name`));

