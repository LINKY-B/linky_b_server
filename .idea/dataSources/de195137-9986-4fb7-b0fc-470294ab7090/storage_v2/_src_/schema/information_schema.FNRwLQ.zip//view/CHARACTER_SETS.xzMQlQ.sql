CREATE VIEW CHARACTER_SETS AS
SELECT `cs`.`name`          AS `CHARACTER_SET_NAME`,
       `col`.`name`         AS `DEFAULT_COLLATE_NAME`,
       `cs`.`comment`       AS `DESCRIPTION`,
       `cs`.`mb_max_length` AS `MAXLEN`
FROM (`mysql`.`character_sets` `cs` JOIN `mysql`.`collations` `col` ON ((`cs`.`default_collation_id` = `col`.`id`)));

