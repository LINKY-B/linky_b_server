CREATE VIEW COLLATION_CHARACTER_SET_APPLICABILITY AS
SELECT `col`.`name` AS `COLLATION_NAME`, `cs`.`name` AS `CHARACTER_SET_NAME`
FROM (`mysql`.`character_sets` `cs` JOIN `mysql`.`collations` `col` ON ((`cs`.`id` = `col`.`character_set_id`)));

