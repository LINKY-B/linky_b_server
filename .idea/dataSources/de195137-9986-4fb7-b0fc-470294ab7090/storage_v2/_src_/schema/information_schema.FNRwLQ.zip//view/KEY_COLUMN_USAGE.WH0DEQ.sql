CREATE VIEW KEY_COLUMN_USAGE AS
SELECT `cat`.`name`                                  AS `CONSTRAINT_CATALOG`,
       `sch`.`name`                                  AS `CONSTRAINT_SCHEMA`,
       `constraints`.`CONSTRAINT_NAME`               AS `CONSTRAINT_NAME`,
       `cat`.`name`                                  AS `TABLE_CATALOG`,
       `sch`.`name`                                  AS `TABLE_SCHEMA`,
       `tbl`.`name`                                  AS `TABLE_NAME`,
       (`col`.`name` COLLATE utf8_tolower_ci)        AS `COLUMN_NAME`,
       `constraints`.`ORDINAL_POSITION`              AS `ORDINAL_POSITION`,
       `constraints`.`POSITION_IN_UNIQUE_CONSTRAINT` AS `POSITION_IN_UNIQUE_CONSTRAINT`,
       `constraints`.`REFERENCED_TABLE_SCHEMA`       AS `REFERENCED_TABLE_SCHEMA`,
       `constraints`.`REFERENCED_TABLE_NAME`         AS `REFERENCED_TABLE_NAME`,
       `constraints`.`REFERENCED_COLUMN_NAME`        AS `REFERENCED_COLUMN_NAME`
FROM (((`mysql`.`tables` `tbl` JOIN `mysql`.`schemata` `sch`
        ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
       ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN (LATERAL (SELECT `idx`.`name`                                     AS `CONSTRAINT_NAME`,
                                                                     `icu`.`ordinal_position`                         AS `ORDINAL_POSITION`,
                                                                     NULL                                             AS `POSITION_IN_UNIQUE_CONSTRAINT`,
                                                                     NULL                                             AS `REFERENCED_TABLE_SCHEMA`,
                                                                     NULL                                             AS `REFERENCED_TABLE_NAME`,
                                                                     NULL                                             AS `REFERENCED_COLUMN_NAME`,
                                                                     `icu`.`column_id`                                AS `column_id`,
                                                                     ((0 <> `idx`.`hidden`) OR (0 <> `icu`.`hidden`)) AS `HIDDEN`
                                                              FROM (`mysql`.`indexes` `idx` JOIN `mysql`.`index_column_usage` `icu`
                                                                    ON ((`icu`.`index_id` = `idx`.`id`)))
                                                              WHERE ((`idx`.`table_id` = `tbl`.`id`) AND
                                                                     (`idx`.`type` IN ('PRIMARY', 'UNIQUE')))
                                                              UNION ALL
                                                              SELECT (`fk`.`name` COLLATE utf8_tolower_ci) AS `CONSTRAINT_NAME`,
                                                                     `fkcu`.`ordinal_position`             AS `ORDINAL_POSITION`,
                                                                     `fkcu`.`ordinal_position`             AS `POSITION_IN_UNIQUE_CONSTRAINT`,
                                                                     `fk`.`referenced_table_schema`        AS `REFERENCED_TABLE_SCHEMA`,
                                                                     `fk`.`referenced_table_name`          AS `REFERENCED_TABLE_NAME`,
                                                                     `fkcu`.`referenced_column_name`       AS `REFERENCED_COLUMN_NAME`,
                                                                     `fkcu`.`column_id`                    AS `column_id`,
                                                                     FALSE                                 AS `HIDDEN`
                                                              FROM (`mysql`.`foreign_keys` `fk` JOIN `mysql`.`foreign_key_column_usage` `fkcu`
                                                                    ON ((`fkcu`.`foreign_key_id` = `fk`.`id`)))
                                                              WHERE (`fk`.`table_id` = `tbl`.`id`)) `constraints` JOIN `mysql`.`columns` `col`
                                                     ON ((`constraints`.`column_id` = `col`.`id`))))
WHERE ((0 <> can_access_column(`sch`.`name`, `tbl`.`name`, `col`.`name`)) AND
       (0 <> is_visible_dd_object(`tbl`.`hidden`, ((`col`.`hidden` <> 'Visible') OR (0 <> `constraints`.`HIDDEN`)))));

