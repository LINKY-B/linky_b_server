CREATE VIEW ROLE_COLUMN_GRANTS AS
WITH RECURSIVE `role_graph` (`c_parent_user`, `c_parent_host`, `c_from_user`, `c_from_host`, `c_to_user`, `c_to_host`,
                             `role_path`, `c_with_admin`, `c_enabled`)
                   AS (SELECT internal_get_username()                        AS `INTERNAL_GET_USERNAME()`,
                              internal_get_hostname()                        AS `INTERNAL_GET_HOSTNAME()`,
                              internal_get_username()                        AS `INTERNAL_GET_USERNAME()`,
                              internal_get_hostname()                        AS `INTERNAL_GET_HOSTNAME()`,
                              CAST('' AS char(64) CHARSET utf8mb4)           AS `CAST('' as CHAR(64) CHARSET utf8mb4)`,
                              CAST('' AS char(255) CHARSET utf8mb4)          AS `CAST('' as CHAR(255) CHARSET utf8mb4)`,
                              CAST(SHA2(CONCAT(QUOTE(internal_get_username()), '@', QUOTE(internal_get_hostname())),
                                        256) AS char(17000) CHARSET utf8mb4) AS `CAST(SHA2(CONCAT(QUOTE(INTERNAL_GET_USERNAME()),'@',                        QUOTE(INTERNAL_GET_HOSTNAME())), 256)            AS CHAR(17000) CHARSET utf8mb4)`,
                              CAST('N' AS char(1) CHARSET utf8mb4)           AS `CAST('N' as CHAR(1) CHARSET utf8mb4)`,
                              FALSE                                          AS `FALSE`
                       UNION
                       SELECT internal_get_username()                        AS `INTERNAL_GET_USERNAME()`,
                              internal_get_hostname()                        AS `INTERNAL_GET_HOSTNAME()`,
                              `mandatory_roles`.`ROLE_NAME`                  AS `ROLE_NAME`,
                              `mandatory_roles`.`ROLE_HOST`                  AS `ROLE_HOST`,
                              internal_get_username()                        AS `INTERNAL_GET_USERNAME()`,
                              internal_get_hostname()                        AS `INTERNAL_GET_HOSTNAME()`,
                              CAST(SHA2(CONCAT(QUOTE(`mandatory_roles`.`ROLE_NAME`), '@',
                                               CONVERT(QUOTE(`mandatory_roles`.`ROLE_HOST`) USING utf8mb4)),
                                        256) AS char(17000) CHARSET utf8mb4) AS `CAST(SHA2(CONCAT(QUOTE(ROLE_NAME),'@',                   CONVERT(QUOTE(ROLE_HOST) using utf8mb4)), 256)              AS CHAR(17000) CHARSET utf8mb4)`,
                              CAST('N' AS char(1) CHARSET utf8mb4)           AS `CAST('N' as CHAR(1) CHARSET utf8mb4)`,
                              FALSE                                          AS `FALSE`
                       FROM JSON_TABLE(internal_get_mandatory_roles_json(), '$[*]'
                                       COLUMNS (`ROLE_NAME` varchar(255) CHARACTER SET utf8mb4 PATH '$.ROLE_NAME', `ROLE_HOST` varchar(255) CHARACTER SET utf8mb4 PATH '$.ROLE_HOST')) `mandatory_roles`
                       WHERE CONCAT(QUOTE(`mandatory_roles`.`ROLE_NAME`), '@',
                                    CONVERT(QUOTE(`mandatory_roles`.`ROLE_HOST`) USING utf8mb4)) IN
                             (SELECT CONCAT(CONVERT(QUOTE(`mysql`.`role_edges`.`FROM_USER`) USING utf8mb4), '@',
                                            CONVERT(QUOTE(`mysql`.`role_edges`.`FROM_HOST`) USING utf8mb4))
                              FROM `mysql`.`role_edges`
                              WHERE ((`mysql`.`role_edges`.`TO_USER` = internal_get_username()) AND
                                     (CONVERT(`mysql`.`role_edges`.`TO_HOST` USING utf8mb4) =
                                      CONVERT(internal_get_hostname() USING utf8mb4)))) IS FALSE
                       UNION
                       SELECT `role_graph`.`c_parent_user`                                                       AS `c_parent_user`,
                              `role_graph`.`c_parent_host`                                                       AS `c_parent_host`,
                              `mysql`.`role_edges`.`FROM_USER`                                                   AS `FROM_USER`,
                              `mysql`.`role_edges`.`FROM_HOST`                                                   AS `FROM_HOST`,
                              `mysql`.`role_edges`.`TO_USER`                                                     AS `TO_USER`,
                              `mysql`.`role_edges`.`TO_HOST`                                                     AS `TO_HOST`,
                              IF((LOCATE(SHA2(CONCAT(CONVERT(QUOTE(`mysql`.`role_edges`.`FROM_USER`) USING utf8mb4),
                                                     '@',
                                                     CONVERT(QUOTE(`mysql`.`role_edges`.`FROM_HOST`) USING utf8mb4)),
                                              256), `role_graph`.`role_path`) = 0),
                                 CONCAT(`role_graph`.`role_path`, '->', CONVERT(SHA2(CONCAT(
                                                                                             CONVERT(QUOTE(`mysql`.`role_edges`.`FROM_USER`) USING utf8mb4),
                                                                                             '@',
                                                                                             CONVERT(QUOTE(`mysql`.`role_edges`.`FROM_HOST`) USING utf8mb4)),
                                                                                     256) USING utf8mb4)),
                                 NULL)                                                                           AS `IF(LOCATE(SHA2(CONCAT(QUOTE(FROM_USER),'@',                      CONVERT(QUOTE(FROM_HOST) using utf8mb4)), 256),                 role_path) = 0,          CONCAT(role_path,'->', SHA2(CONCAT(QUOTE(FROM_USER),'@',           CONVERT(QUOTE(FROM_HOST) using utf8`,
                              `mysql`.`role_edges`.`WITH_ADMIN_OPTION`                                           AS `WITH_ADMIN_OPTION`,
                              IF(((0 <> `role_graph`.`c_enabled`) OR (0 <> internal_is_enabled_role(
                                      `mysql`.`role_edges`.`FROM_USER`, `mysql`.`role_edges`.`FROM_HOST`))), TRUE,
                                 FALSE)                                                                          AS `IF(c_enabled OR        INTERNAL_IS_ENABLED_ROLE(FROM_USER, FROM_HOST), TRUE, FALSE)`
                       FROM (`mysql`.`role_edges` JOIN `role_graph`)
                       WHERE ((`mysql`.`role_edges`.`TO_USER` = `role_graph`.`c_from_user`) AND
                              (CONVERT(`mysql`.`role_edges`.`TO_HOST` USING utf8mb4) = `role_graph`.`c_from_host`) AND
                              (`role_graph`.`role_path` IS NOT NULL)))
SELECT DISTINCT internal_get_username(`tp`.`Grantor`)                          AS `GRANTOR`,
                internal_get_hostname(`tp`.`Grantor`)                          AS `GRANTOR_HOST`,
                `cp`.`User`                                                    AS `GRANTEE`,
                `cp`.`Host`                                                    AS `GRANTEE_HOST`,
                'def'                                                          AS `TABLE_CATALOG`,
                `cp`.`Db`                                                      AS `TABLE_SCHEMA`,
                `cp`.`Table_name`                                              AS `TABLE_NAME`,
                `cp`.`Column_name`                                             AS `COLUMN_NAME`,
                `cp`.`Column_priv`                                             AS `PRIVILEGE_TYPE`,
                IF((FIND_IN_SET('Grant', `tp`.`Table_priv`) > 0), 'YES', 'NO') AS `IS_GRANTABLE`
FROM ((`mysql`.`tables_priv` `tp` JOIN `role_graph` `rg` ON (((`tp`.`User` = `rg`.`c_from_user`) AND
                                                              (CONVERT(`tp`.`Host` USING utf8mb4) = `rg`.`c_from_host`)))) JOIN `mysql`.`columns_priv` `cp`
      ON (((CONVERT(`tp`.`Host` USING utf8mb4) = `cp`.`Host`) AND (`cp`.`Db` = `tp`.`Db`) AND
           (`cp`.`User` = `tp`.`User`) AND (`cp`.`Table_name` = `tp`.`Table_name`))))
WHERE ((`cp`.`Column_priv` > 0) AND (`rg`.`c_to_user` <> '') AND (`rg`.`c_enabled` = TRUE));

