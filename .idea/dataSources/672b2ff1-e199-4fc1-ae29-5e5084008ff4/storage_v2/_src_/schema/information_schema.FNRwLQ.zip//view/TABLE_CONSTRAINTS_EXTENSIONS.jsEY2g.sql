CREATE VIEW TABLE_CONSTRAINTS_EXTENSIONS AS
SELECT `cat`.`name`                       AS `CONSTRAINT_CATALOG`,
       `sch`.`name`                       AS `CONSTRAINT_SCHEMA`,
       `idx`.`name`                       AS `CONSTRAINT_NAME`,
       `tbl`.`name`                       AS `TABLE_NAME`,
       `idx`.`engine_attribute`           AS `ENGINE_ATTRIBUTE`,
       `idx`.`secondary_engine_attribute` AS `SECONDARY_ENGINE_ATTRIBUTE`
FROM (((`mysql`.`indexes` `idx` JOIN `mysql`.`tables` `tbl`
        ON ((`idx`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`schemata` `sch`
       ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat` ON ((`cat`.`id` = `sch`.`catalog_id`)))
WHERE ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) AND (0 <> is_visible_dd_object(`tbl`.`hidden`)));

