CREATE VIEW VIEW_TABLE_USAGE AS
SELECT `cat`.`name`          AS `VIEW_CATALOG`,
       `sch`.`name`          AS `VIEW_SCHEMA`,
       `vw`.`name`           AS `VIEW_NAME`,
       `vtu`.`table_catalog` AS `TABLE_CATALOG`,
       `vtu`.`table_schema`  AS `TABLE_SCHEMA`,
       `vtu`.`table_name`    AS `TABLE_NAME`
FROM (((`mysql`.`tables` `vw` JOIN `mysql`.`schemata` `sch`
        ON ((`vw`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
       ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`view_table_usage` `vtu` ON ((`vtu`.`view_id` = `vw`.`id`)))
WHERE ((0 <> can_access_table(`vtu`.`table_schema`, `vtu`.`table_name`)) AND (`vw`.`type` = 'VIEW') AND
       (0 <> can_access_view(`sch`.`name`, `vw`.`name`, `vw`.`view_definer`, `vw`.`options`)));

