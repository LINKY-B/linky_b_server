CREATE VIEW INNODB_FOREIGN AS
SELECT CONCAT(`sch`.`name`, '/', `fk`.`name`)                                                            AS `ID`,
       CONCAT(`sch`.`name`, '/', `tbl`.`name`)                                                           AS `FOR_NAME`,
       CONCAT(`fk`.`referenced_table_schema`, '/', `fk`.`referenced_table_name`)                         AS `REF_NAME`,
       COUNT(0)                                                                                          AS `N_COLS`,
       (((((IF((`fk`.`delete_rule` = 'CASCADE'), 1, 0) | IF((`fk`.`delete_rule` = 'SET NULL'), 2, 0)) |
           IF((`fk`.`update_rule` = 'CASCADE'), 4, 0)) | IF((`fk`.`update_rule` = 'SET NULL'), 8, 0)) |
         IF((`fk`.`delete_rule` = 'NO ACTION'), 16, 0)) | IF((`fk`.`update_rule` = 'NO ACTION'), 32, 0)) AS `TYPE`
FROM (((`mysql`.`foreign_keys` `fk` JOIN `mysql`.`tables` `tbl`
        ON ((`fk`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`schemata` `sch`
       ON ((`fk`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`foreign_key_column_usage` `col`
      ON ((`fk`.`id` = `col`.`foreign_key_id`)))
WHERE ((`tbl`.`type` <> 'VIEW') AND (`tbl`.`hidden` = 'Visible') AND (`tbl`.`se_private_id` IS NOT NULL) AND
       (`tbl`.`engine` = 'INNODB'))
GROUP BY `fk`.`id`;

