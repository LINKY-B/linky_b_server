CREATE VIEW COLUMNS AS
SELECT `cat`.`name`                                                                                       AS `TABLE_CATALOG`,
       `sch`.`name`                                                                                       AS `TABLE_SCHEMA`,
       `tbl`.`name`                                                                                       AS `TABLE_NAME`,
       (`col`.`name` COLLATE utf8_tolower_ci)                                                             AS `COLUMN_NAME`,
       `col`.`ordinal_position`                                                                           AS `ORDINAL_POSITION`,
       `col`.`default_value_utf8`                                                                         AS `COLUMN_DEFAULT`,
       IF((`col`.`is_nullable` = 1), 'YES', 'NO')                                                         AS `IS_NULLABLE`,
       SUBSTRING_INDEX(SUBSTRING_INDEX(`col`.`column_type_utf8`, '(', 1), ' ',
                       1)                                                                                 AS `DATA_TYPE`,
       internal_dd_char_length(`col`.`type`, `col`.`char_length`, `coll`.`name`,
                               0)                                                                         AS `CHARACTER_MAXIMUM_LENGTH`,
       internal_dd_char_length(`col`.`type`, `col`.`char_length`, `coll`.`name`,
                               1)                                                                         AS `CHARACTER_OCTET_LENGTH`,
       IF((`col`.`numeric_precision` = 0), NULL, `col`.`numeric_precision`)                               AS `NUMERIC_PRECISION`,
       IF(((`col`.`numeric_scale` = 0) AND (`col`.`numeric_precision` = 0)), NULL,
          `col`.`numeric_scale`)                                                                          AS `NUMERIC_SCALE`,
       `col`.`datetime_precision`                                                                         AS `DATETIME_PRECISION`,
       (CASE `col`.`type`
            WHEN 'MYSQL_TYPE_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_VAR_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_VARCHAR' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_TINY_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_MEDIUM_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_LONG_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_ENUM' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_SET' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            ELSE NULL END)                                                                                AS `CHARACTER_SET_NAME`,
       (CASE `col`.`type`
            WHEN 'MYSQL_TYPE_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_VAR_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_VARCHAR' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_TINY_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_MEDIUM_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_LONG_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_ENUM' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            WHEN 'MYSQL_TYPE_SET' THEN IF((`cs`.`name` = 'binary'), NULL, `coll`.`name`)
            ELSE NULL END)                                                                                AS `COLLATION_NAME`,
       `col`.`column_type_utf8`                                                                           AS `COLUMN_TYPE`,
       `col`.`column_key`                                                                                 AS `COLUMN_KEY`,
       internal_get_dd_column_extra((`col`.`generation_expression_utf8` IS NULL), `col`.`is_virtual`,
                                    `col`.`is_auto_increment`, `col`.`update_option`,
                                    IF(LENGTH(`col`.`default_option`), TRUE, FALSE), `col`.`options`, `col`.`hidden`,
                                    `tbl`.`type`)                                                         AS `EXTRA`,
       get_dd_column_privileges(`sch`.`name`, `tbl`.`name`, `col`.`name`)                                 AS `PRIVILEGES`,
       IFNULL(`col`.`comment`, '')                                                                        AS `COLUMN_COMMENT`,
       IFNULL(`col`.`generation_expression_utf8`, '')                                                     AS `GENERATION_EXPRESSION`,
       `col`.`srs_id`                                                                                     AS `SRS_ID`
FROM (((((`mysql`.`columns` `col` JOIN `mysql`.`tables` `tbl`
          ON ((`col`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`schemata` `sch`
         ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
        ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`collations` `coll`
       ON ((`col`.`collation_id` = `coll`.`id`))) JOIN `mysql`.`character_sets` `cs`
      ON ((`coll`.`character_set_id` = `cs`.`id`)))
WHERE ((0 <> internal_get_view_warning_or_error(`sch`.`name`, `tbl`.`name`, `tbl`.`type`, `tbl`.`options`)) AND
       (0 <> can_access_column(`sch`.`name`, `tbl`.`name`, `col`.`name`)) AND
       (0 <> is_visible_dd_object(`tbl`.`hidden`, (`col`.`hidden` NOT IN ('Visible', 'User')))));

