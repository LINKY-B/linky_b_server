create view KEY_COLUMN_USAGE as
-- missing source code
;

