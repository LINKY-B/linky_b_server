create view STATISTICS as
-- missing source code
;

