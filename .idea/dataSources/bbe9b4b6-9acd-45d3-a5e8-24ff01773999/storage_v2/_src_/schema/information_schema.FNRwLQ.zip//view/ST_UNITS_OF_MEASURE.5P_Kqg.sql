create view ST_UNITS_OF_MEASURE as
-- missing source code
;

